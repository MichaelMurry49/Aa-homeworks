class House < ApplicationRecord
    has_many :people,
    class_name: :Person,
    foreign_key: :person_id,
    primary_key: :id
end